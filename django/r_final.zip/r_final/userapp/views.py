from django.shortcuts import render,redirect

# Create your views here.


def home(request):
    return render(request, 'home.html')

def shop(request):
    return render(request, 'book_list.html')

def book_detail(request, id):
    return render(request, 'book_detail.html')

def cart(request):
    return render(request, 'cart.html')

def checkout(request):
    return render(request, 'checkout.html')

def order_success(request):
    return render(request, 'order_success.html')

def login_view(request):
    return render(request, 'login.html')

def register_view(request):
    return render(request, 'register.html')

def profile_view(request):
    return render(request, 'profile.html')

def contact(request):
    return render(request, 'contact.html')

def logout_view(request):
    # અહી લોગઆઉટનું લોજીક આવશે
    return render(request, 'home.html')
