from django.shortcuts import render,redirect

# Create your views here.

def admin_dashboard(request):
    return render(request, 'admin_dashboard.html')

def admin_books(request):
    return render(request, 'admin_books.html')

def admin_add_book(request):
    return render(request, 'admin_add_book.html')

def admin_orders(request):
    return render(request, 'admin_orders.html')

def admin_users(request):
    return render(request, 'admin_users.html')