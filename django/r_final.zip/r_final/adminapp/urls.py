from django.contrib import admin
from django.urls import path,include
from adminapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('admin_dashboard', views.admin_dashboard, name='admin_dashboard'),
    path('admin_books', views.admin_books, name='admin_books'),
    path('admin_add_book', views.admin_add_book, name='admin_add_book'),
    path('admin_orders', views.admin_orders, name='admin_orders'),
    path('admin_users', views.admin_users, name='admin_users'),
]